Refer to README.md in both the server and client directory
